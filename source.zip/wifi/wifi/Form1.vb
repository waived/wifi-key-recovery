﻿Imports System.Diagnostics
Imports System.IO
Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("https://github.com/waived")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Button1.Enabled = False
        System.Threading.ThreadPool.QueueUserWorkItem(Sub() DoWork())
    End Sub

    Private Sub DoWork()
        CheckForIllegalCrossThreadCalls = False

        Try
            ' get ssid/s
            Dim ssids As List(Of String) = GetWiFiSSIDs()

            ' iterate through list and attempt to pull key
            For Each ssid In ssids


                Dim wifiKey As String = GetWiFiKey(ssid)
                If String.IsNullOrEmpty(wifiKey) Then
                    wifiKey = "(none)"
                End If

                Dim newRow As DataGridViewRow = DataGridView1.Rows(DataGridView1.Rows.Add())
                newRow.Cells("colSSID").Value = ssid
                newRow.Cells("colPWD").Value = wifiKey

            Next

            Button1.Enabled = True

        Catch : End Try
    End Sub

    Function GetWiFiSSIDs() As List(Of String)
        Dim ssids As New List(Of String)()
        Try
            ' use command line to pull all profiles
            Dim processStartInfo As New ProcessStartInfo("netsh", "wlan show profiles") With {
                .RedirectStandardOutput = True,
                .UseShellExecute = False,
                .CreateNoWindow = True
            }
            Dim process As Process = Process.Start(processStartInfo)
            Dim reader As System.IO.StreamReader = process.StandardOutput
            Dim output As String = reader.ReadToEnd()
            process.WaitForExit()

            ' format lines to pull ssid/s
            Dim lines() As String = output.Split(New String() {Environment.NewLine}, StringSplitOptions.None)
            For Each line In lines
                If line.Contains("All User Profile") Then
                    Dim ssid As String = line.Split(":")(1).Trim()
                    ssids.Add(ssid)
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        Return ssids
    End Function
    Function GetWiFiKey(ssid As String) As String
        Try
            ' use command line to get key from the ssid
            Dim processStartInfo As New ProcessStartInfo("netsh", $"wlan show profile ""{ssid}"" key=clear") With {
                .RedirectStandardOutput = True,
                .UseShellExecute = False,
                .CreateNoWindow = True
            }
            Dim process As Process = Process.Start(processStartInfo)
            Dim reader As System.IO.StreamReader = process.StandardOutput
            Dim output As String = reader.ReadToEnd()
            process.WaitForExit()

            ' find line w/ with the key
            Dim keyLine As String = output.Split(New String() {Environment.NewLine}, StringSplitOptions.None) _
                                      .FirstOrDefault(Function(line) line.Contains("Key Content"))

            If keyLine IsNot Nothing Then
                ' pull the key value
                Return keyLine.Split(":")(1).Trim()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        Return String.Empty
    End Function

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If DataGridView1.Rows.Count > 0 Then
            Dim _sfd As New SaveFileDialog

            _sfd.Filter = "Text File (*.txt)|*.txt"
            _sfd.InitialDirectory = Environment.SpecialFolder.Desktop

            If _sfd.ShowDialog = DialogResult.OK Then
                Button2.Enabled = False
                System.Threading.ThreadPool.QueueUserWorkItem(Sub() _export(_sfd.FileName))
            End If
        End If
    End Sub
    Private Sub _export(_path As String)
        CheckForIllegalCrossThreadCalls = False

        Try
            Using writer As New StreamWriter(_path, False) ' False means overwrite

                For Each row As DataGridViewRow In DataGridView1.Rows

                    If Not row.IsNewRow Then
                        Dim rowValues As New List(Of String)()

                        For Each cell As DataGridViewCell In row.Cells

                            If cell.Value IsNot Nothing Then
                                rowValues.Add(cell.Value.ToString())
                            Else
                                rowValues.Add(String.Empty)
                            End If
                        Next

                        writer.WriteLine(String.Join(":", rowValues))
                    End If
                Next

                writer.Close()
            End Using
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        MsgBox("Complete!")
        Button2.Enabled = True
    End Sub
End Class
